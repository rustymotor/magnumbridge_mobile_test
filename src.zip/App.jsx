import { useState } from "react";
import BusinessPage from "./pages/business_1.jsx";
import SiteHeader from "./components/SiteHeader.jsx";

const sitemapPages = {
  "/product": ["Business", "Product"],
  "/it-service": ["Business", "IT Service"],
  "/about-magnumbridge": ["Company", "About Magnumbridge"],
  "/customer-partner": ["Company", "Customer & Partner"],
  "/vision-mission": ["Company", "Vision & Mission"],
  "/history": ["Company", "History"],
  "/qa": ["Company", "Q&A"],
  "/ideal-employee": ["Recruit", "Ideal employee"],
  "/benefit": ["Recruit", "Benefit"],
  "/recruitment": ["Recruit", "Recruitment"],
};

const companyCards = [
  ["Vision & Mission", "비전 & 미션", "/assets/vision.jpg"],
  ["Customer & Partner", "고객과 파트너", "/assets/customer.jpg"],
  ["Good employee", "인재상", "/assets/people.jpg"],
  ["History", "연혁", "/assets/history.jpg"],
];
const techItems = [
  ["Core", "고성능 분산 처리 엔진"],
  ["WebView", "웹 기반 통합 인터페이스"],
  ["AI4Frame-Rdbms BASIC", "Repository & API 연계 · SQL 지원 · 실시간 데이터 처리"],
  ["Security", "데이터 보안 및 접근 제어"],
  ["Batch", "대용량 배치 프로세싱"],
  ["adminConsole", "간편한 통합 운영 관리"],
];
const performances = [
  ["NPS 국민연금", "통합운영관리 시스템", "2024.04", "/assets/coop1.png", 42],
  ["신한은행", "AI 기반 업무 고도화", "2024.04", "/assets/coop2.png", 39],
  ["SGI서울보증", "데이터 플랫폼 구축", "2024.07", "/assets/coop3.png", 36],
  ["신한라이프", "IT 통합운영 시스템", "2023.08", "/assets/coop4.png", 46],
  ["KB손해보험", "K-Insight 시스템 고도화", "2024.06", "/assets/coop5.png", 39],
  ["NICE평가정보", "기업정보 플랫폼", "2023.06", "/assets/coop6.png", 34],
];

export default function App() {
  const [activeTech, setActiveTech] = useState(null);

  if (window.location.pathname === "/platform-solution") {
    return <BusinessPage />;
  }

  const sitemapPage = sitemapPages[window.location.pathname];

  if (sitemapPage) {
    return (
      <BusinessPage
        emptyContent
        heroSection={sitemapPage[0]}
        heroTitle={sitemapPage[1]}
        productContent={window.location.pathname === "/product"}
      />
    );
  }

  return (
    <main key="home-page-source-synced">
      <SiteHeader />

      <section
        id="top"
        className="hero hero-slider"
        ref={(hero) => {
          if (!hero) return;

          let currentSlide = 0;
          const track = hero.querySelector(".hero-track");
          const dots = hero.querySelectorAll(".pagination span");

          const timer = window.setInterval(() => {
            currentSlide += 1;
            track.style.transition = "transform 700ms ease";
            track.style.transform = `translateX(-${currentSlide * 100}%)`;
            dots.forEach((dot, index) => {
              dot.classList.toggle("active", index === currentSlide % 3);
            });

            if (currentSlide === 3) {
              window.setTimeout(() => {
                track.style.transition = "none";
                track.style.transform = "translateX(0)";
                currentSlide = 0;
              }, 700);
            }
          }, 3000);

          return () => window.clearInterval(timer);
        }}
      >
        <div className="hero-track">
          {[
            "hero-slide-main",
            "hero-slide-vision",
            "hero-slide-customer",
            "hero-slide-main",
          ].map((slideClass, index) => (
            <div
              className={`hero-inner ${slideClass}`}
              aria-hidden={index === 3 ? "true" : undefined}
              key={`${slideClass}-${index}`}
            >
              <div className="hero-slide-content">
                <p
                  className="hero-copy"
                  style={index < 3 ? { fontSize: "32px" } : undefined}
                >
                  We are talking<br />about trust,<br />creativity,<br />and innovation<br />through technology.
                </p>
                <a href="#company" className="view-more" tabIndex={index === 3 ? -1 : undefined}>view more</a>
              </div>
            </div>
          ))}
        </div>
        <div className="pagination"><span className="active" /><span /><span /></div>
      </section>

      <section
        id="company"
        className="section company"
        style={{ paddingBottom: 0 }}
      >
        <SectionTitle title="Company Overview" style={{ fontSize: "24px" }} />
        <p className="section-copy" style={{ marginTop: "40px", color: "#000", fontSize: "18px" }}>지식 기반의 “AI4Frame” 기술을 바탕으로,<br />고객의 가치 기술 경쟁을 위해 함께 성장해 나가는 IT 플랫폼 기업입니다.</p>
        <div className="center"><a href="#footer" className="pill pill-red">About&nbsp;&nbsp;Magnumbridge</a></div>
        <div className="company-grid">
          {companyCards.map(([title, ko, image]) => (
            <article
              className="company-card move_up"
              key={`${title}-directional-move-up`}
              ref={(element) => {
                if (!element) return;

                const observer = new IntersectionObserver(([entry]) => {
                  const viewportTop = entry.rootBounds?.top ?? 0;
                  const viewportBottom = entry.rootBounds?.bottom ?? window.innerHeight;

                  if (entry.isIntersecting || entry.boundingClientRect.bottom <= viewportTop) {
                    entry.target.classList.add("is-visible");
                  } else if (entry.boundingClientRect.top >= viewportBottom) {
                    entry.target.classList.remove("is-visible");
                  }
                }, { threshold: 0.1 });

                observer.observe(element);
                return () => observer.disconnect();
              }}
            >
              <img src={image} alt="" />
              <div className="card-overlay"><h3>{title}</h3><p>{ko}</p></div>
            </article>
          ))}
        </div>
      </section>

      <section
        className="section"
        style={{ paddingRight: "20px", paddingBottom: "60px", paddingLeft: "20px" }}
      >
        <SectionTitle title="Tech Overview" style={{ fontSize: "24px" }} />
        <p className="section-copy" style={{ marginTop: "40px", color: "#000", fontSize: "18px" }}>풍부한 경험과 전문성을 바탕으로 고객의 요구사항을 효과적으로 수행할 수 있는 프레임워크&nbsp;&nbsp;”All4Frame”을 제공합니다.</p>
      </section>

      <section
        id="tech"
        className="section tech"
        key="tech-section-source-synced"
        style={{ paddingTop: "60px", paddingBottom: "60px" }}
      >
        <div className="section-inner">
          <p
            className="tech-label"
            style={{ marginTop: 0, fontSize: "20px", fontWeight: 400 }}
          >
            All4Frame 패키지별 특징
          </p>
          <div
            className="tech-list"
            style={{ marginRight: 0, marginBottom: 0, marginLeft: 0 }}
          >
            {techItems.map(([title, detail], index) => (
              <button
                key={title}
                onMouseEnter={() => setActiveTech(index)}
                onMouseLeave={() => setActiveTech(null)}
                onFocus={() => setActiveTech(index)}
                onBlur={() => setActiveTech(null)}
                className={`tech-item tech-item-${index + 1} ${activeTech === index ? "active" : ""}`}
              >
                <span className="tech-row"><strong>{title}</strong><span>{activeTech === index ? "−" : "↗"}</span></span>
                {activeTech === index && <span className="tech-detail">{detail}<br />안정적인 엔터프라이즈 환경과 유연한 확장성을 제공합니다.</span>}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section
        className="section"
        style={{ paddingRight: "20px", paddingBottom: "60px", paddingLeft: "20px" }}
      >
        <SectionTitle title="Performance" style={{ fontSize: "24px" }} />
        <p className="section-copy" style={{ marginTop: "40px", color: "#000", fontSize: "18px" }}>다양한 프로젝트를 수행한, 경험 많은 다수의 개발자들과 함께 합니다.고객의 사업에 가장 효과적인 Solution을 제공하고, 효과적인 운영을 위한 설계를 지향합니다.</p>
      </section>

      <section
        id="performance"
        className="section performance"
        style={{ paddingTop: "40px", paddingBottom: "100px" }}
      >
        <div className="section-inner">
          <div className="filter-buttons"><button className="pill pill-black">솔루션 Solution</button><button className="pill pill-outline">IT Service</button></div>
          <div className="performance-grid" style={{ marginTop: "30px" }}>
            {performances.map(([name, project, date, logo, logoHeight]) => (
              <article
                className="performance-card move_up"
                key={`${name}-directional-move-up`}
                ref={(element) => {
                  if (!element) return;

                  const observer = new IntersectionObserver(([entry]) => {
                    const viewportTop = entry.rootBounds?.top ?? 0;
                    const viewportBottom = entry.rootBounds?.bottom ?? window.innerHeight;

                    if (entry.isIntersecting || entry.boundingClientRect.bottom <= viewportTop) {
                      entry.target.classList.add("is-visible");
                    } else if (entry.boundingClientRect.top >= viewportBottom) {
                      entry.target.classList.remove("is-visible");
                    }
                  }, { threshold: 0.1 });

                  observer.observe(element);
                  return () => observer.disconnect();
                }}
              >
                <div className="client">
                  <img
                    src={logo}
                    alt={`${name} 로고`}
                    style={{ width: "auto", maxWidth: "100%", height: `${logoHeight}px` }}
                  />
                </div>
                <dl><dt>프로젝트명</dt><dd>{project}</dd><dt>솔루션</dt><dd>AI4Frame</dd><dt>수행기간</dt><dd>{date}</dd></dl>
              </article>
            ))}
          </div>
        </div>
      </section>

      <footer id="footer">
        <div className="footer-inner">
          {["Business", "Company", "Recruit"].map((item) => <button className="footer-menu" key={item}>{item}<span>⌄</span></button>)}
          <div className="footer-info"><div className="footer-logo">A</div><p><strong>(주)명성</strong></p><p>서울특별시 · 대표전화 02-0000-0000</p><p>© AI4Frame. All rights reserved.</p></div>
        </div>
      </footer>
    </main>
  );
}

function SectionTitle({ title, style }) {
  return <h2 className="section-title" style={style}>{title}</h2>;
}
